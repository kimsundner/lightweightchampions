annyang samples
===============

Sample script files to control popular sites with voice commands. Intended as inspiration.

To try it, run the site's minified source code in the web developer console.
